from fastapi import APIRouter, Depends, HTTPException, BackgroundTasks
from sqlalchemy.orm import Session
from typing import List
from .. import models, schemas
from ..database import get_db
from ..services.floor_plan_generator import generate_floor_plans
import json

router = APIRouter(prefix="/api/v1/plans", tags=["plans"])

@router.post("/{project_id}/generate")
async def generate_plans(
    project_id: int,
    user_id: int,
    background_tasks: BackgroundTasks,
    db: Session = Depends(get_db)
):
    """Generate floor plans for a project"""
    # Get project
    project = db.query(models.Project).filter(
        models.Project.id == project_id,
        models.Project.user_id == user_id
    ).first()
    
    if not project:
        raise HTTPException(status_code=404, detail="Project not found")
    
    # Generate plans with safe defaults for None values
    try:
        project_data = {
            'land_width': float(project.land_width) if project.land_width is not None else 15.0,
            'land_depth': float(project.land_depth) if project.land_depth is not None else 30.0,
            'bedrooms': int(project.bedrooms) if project.bedrooms is not None else 3,
            'bathrooms': float(project.bathrooms) if project.bathrooms is not None else 2.0,
            'living_areas': int(project.living_areas) if project.living_areas is not None else 1,
            'garage_spaces': int(project.garage_spaces) if project.garage_spaces is not None else 2,
            'open_plan': project.open_plan if project.open_plan is not None else True,
        }
        
        print(f"🏗️  Generating floor plan for project {project_id}")
        print(f"   Data: {project_data}")
        
        layouts = generate_floor_plans(project_data)
        
        # Save to database
        for idx, layout in enumerate(layouts):
            floor_plan = models.FloorPlan(
                project_id=project_id,
                variant_number=idx + 1,
                total_area=layout['total_area'],
                living_area=layout['living_area'],
                plan_type=models.PlanType.BASIC,
                layout_data=json.dumps(layout),
                is_compliant=layout['compliant'],
                compliance_notes=layout['compliance_notes'],
                generation_time_seconds=0.5,
                ai_model_version='rule-based-v1'
            )
            db.add(floor_plan)
        
        # Update project status
        project.status = models.ProjectStatus.COMPLETED
        db.commit()
        
        print(f"✅ Successfully generated {len(layouts)} floor plan(s) for project {project_id}")
        
        return {
            "message": "Floor plans generated successfully", 
            "count": len(layouts),
            "project_id": project_id
        }
        
    except Exception as e:
        project.status = models.ProjectStatus.FAILED
        db.commit()
        print(f"❌ Error generating plans: {str(e)}")
        import traceback
        traceback.print_exc()
        raise HTTPException(status_code=500, detail=str(e))

@router.get("/{project_id}/plans")
async def get_plans(
    project_id: int,
    user_id: int,
    db: Session = Depends(get_db)
):
    """Get all floor plans for a project"""
    # Verify project belongs to user
    project = db.query(models.Project).filter(
        models.Project.id == project_id,
        models.Project.user_id == user_id
    ).first()
    
    if not project:
        raise HTTPException(status_code=404, detail="Project not found")
    
    plans = db.query(models.FloorPlan).filter(
        models.FloorPlan.project_id == project_id
    ).all()
    
    return plans