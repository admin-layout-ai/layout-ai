from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from .routers import projects, users, plans 
from .database import engine, Base
import os
from dotenv import load_dotenv

load_dotenv()

# Create database tables
Base.metadata.create_all(bind=engine)

app = FastAPI(
    title="Layout AI API",
    version="1.0.0",
    description="AI-powered floor plan generation for Australian builders"
)

# CORS
app.add_middleware(
    CORSMiddleware,
    allow_origins=[
        "http://localhost:3000",
        "https://layout-ai.com.au",
        "https://*.azurestaticapps.net"
    ],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Include routers
app.include_router(users.router) 
app.include_router(projects.router)
app.include_router(plans.router)

@app.get("/")
async def root():
    return {
        "message": "Layout AI API",
        "version": "1.0.0",
        "status": "running"
    }

@app.get("/health")
async def health():
    return {"status": "healthy"}