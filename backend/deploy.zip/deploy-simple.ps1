# Simple Deployment Script for Layout-AI
# Run from: C:\Users\vmadmin\Documents\layout-ai\backend

Write-Host "Layout-AI Backend Deployment" -ForegroundColor Cyan
Write-Host ""

# Check location
if (!(Test-Path "app\main.py")) {
    Write-Host "ERROR: Run this from the backend directory!" -ForegroundColor Red
    exit 1
}

Write-Host "Step 1: Backing up main.py..." -ForegroundColor Yellow
$timestamp = Get-Date -Format "yyyyMMdd_HHmmss"
Copy-Item "app\main.py" "app\main.py.backup_$timestamp" -ErrorAction SilentlyContinue
Write-Host "Done" -ForegroundColor Green

Write-Host ""
Write-Host "Step 2: Download the fixed main.py from outputs folder" -ForegroundColor Yellow
Write-Host "Replace your app\main.py with the main_fixed.py I provided" -ForegroundColor Yellow
Write-Host ""
$continue = Read-Host "Have you replaced app\main.py with the fixed version? (y/n)"

if ($continue -ne "y") {
    Write-Host "Please replace app\main.py first, then run this script again" -ForegroundColor Yellow
    exit 0
}

Write-Host ""
Write-Host "Step 3: Creating __init__.py files..." -ForegroundColor Yellow
New-Item -Path "app\__init__.py" -ItemType File -Force | Out-Null
New-Item -Path "app\routers\__init__.py" -ItemType File -Force -ErrorAction SilentlyContinue | Out-Null
New-Item -Path "app\services\__init__.py" -ItemType File -Force -ErrorAction SilentlyContinue | Out-Null
Write-Host "Done" -ForegroundColor Green

Write-Host ""
Write-Host "Step 4: Creating deployment package..." -ForegroundColor Yellow
Remove-Item "deploy.zip" -ErrorAction SilentlyContinue

# Include only necessary files
$itemsToZip = @()
if (Test-Path "app") { $itemsToZip += "app" }
if (Test-Path "requirements.txt") { $itemsToZip += "requirements.txt" }
if (Test-Path "alembic") { $itemsToZip += "alembic" }
if (Test-Path "alembic.ini") { $itemsToZip += "alembic.ini" }

Compress-Archive -Path $itemsToZip -DestinationPath "deploy.zip" -Force
Write-Host "Created deploy.zip" -ForegroundColor Green

Write-Host ""
Write-Host "Step 5: Stopping app..." -ForegroundColor Yellow
az webapp stop --name layoutai-api-dev --resource-group rg-layoutai-dev 2>$null
Start-Sleep -Seconds 5
Write-Host "Done" -ForegroundColor Green

Write-Host ""
Write-Host "Step 6: Deploying to Azure (this takes 2-3 minutes)..." -ForegroundColor Yellow
az webapp deployment source config-zip --name layoutai-api-dev --resource-group rg-layoutai-dev --src deploy.zip

if ($LASTEXITCODE -ne 0) {
    Write-Host "Deployment failed!" -ForegroundColor Red
    exit 1
}
Write-Host "Deployment complete" -ForegroundColor Green

Write-Host ""
Write-Host "Step 7: Configuring startup command..." -ForegroundColor Yellow
az webapp config set --name layoutai-api-dev --resource-group rg-layoutai-dev --startup-file "python -m uvicorn app.main:app --host 0.0.0.0 --port 8000 --log-level info" 2>$null
Write-Host "Done" -ForegroundColor Green

Write-Host ""
Write-Host "Step 8: Starting app..." -ForegroundColor Yellow
az webapp start --name layoutai-api-dev --resource-group rg-layoutai-dev 2>$null
Write-Host "Done" -ForegroundColor Green

Write-Host ""
Write-Host "Step 9: Waiting 60 seconds for startup..." -ForegroundColor Yellow
Start-Sleep -Seconds 60

Write-Host ""
Write-Host "Step 10: Testing API..." -ForegroundColor Yellow

$success = $false
for ($i = 1; $i -le 10; $i++) {
    Write-Host "  Test attempt $i/10..." -ForegroundColor Gray
    
    try {
        $response = Invoke-WebRequest -Uri "https://layoutai-api-dev.azurewebsites.net/health" -UseBasicParsing -TimeoutSec 20
        
        if ($response.StatusCode -eq 200) {
            $success = $true
            Write-Host ""
            Write-Host "SUCCESS! API is running!" -ForegroundColor Green
            Write-Host ""
            Write-Host "URLs:" -ForegroundColor Cyan
            Write-Host "  https://layoutai-api-dev.azurewebsites.net" -ForegroundColor White
            Write-Host "  https://layoutai-api-dev.azurewebsites.net/health" -ForegroundColor White
            Write-Host "  https://layoutai-api-dev.azurewebsites.net/docs" -ForegroundColor White
            Write-Host ""
            
            Start-Process "https://layoutai-api-dev.azurewebsites.net/docs"
            break
        }
    }
    catch {
        if ($i -lt 10) {
            Start-Sleep -Seconds 10
        }
    }
}

if (!$success) {
    Write-Host ""
    Write-Host "API didn't respond. Checking logs..." -ForegroundColor Yellow
    Write-Host ""
    az webapp log tail --name layoutai-api-dev --resource-group rg-layoutai-dev
}
